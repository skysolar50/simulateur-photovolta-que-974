import React, { useState } from 'react';

function App() {
  const [inputs, setInputs] = useState({
    consommation: 6000,
    autoconsommation: 50,
    prixKit: 8000,
  });

  const [results, setResults] = useState(null);

  const handleChange = (e) => {
    setInputs({ ...inputs, [e.target.name]: parseFloat(e.target.value) });
  };

  const calculer = () => {
    const { consommation, autoconsommation, prixKit } = inputs;
    const tarif = 0.23;
    const irradiance = 1900;

    const production = consommation;
    const autoPart = production * (autoconsommation / 100);
    const gainAuto = autoPart * tarif;
    const gainAnnuel = gainAuto;
    const retourInvest = prixKit / gainAnnuel;

    const factureSansPV = consommation * tarif;
    const factureAvecPV = factureSansPV - gainAnnuel;

    setResults({
      production: Math.round(production),
      gainAnnuel: gainAnnuel.toFixed(2),
      retourInvest: retourInvest.toFixed(1),
      factureSansPV: factureSansPV.toFixed(2),
      factureAvecPV: factureAvecPV.toFixed(2),
    });
  };

  return (
    <div style={{ maxWidth: '600px', margin: 'auto', fontFamily: 'sans-serif' }}>
      <h1>Simulateur Photovoltaïque – La Réunion</h1>
      <label>
        Consommation annuelle (kWh)
        <input type="number" name="consommation" value={inputs.consommation} onChange={handleChange} />
      </label>
      <label>
        Taux d'autoconsommation (%)
        <input type="number" name="autoconsommation" value={inputs.autoconsommation} onChange={handleChange} />
      </label>
      <label>
        Prix du kit (€)
        <input type="number" name="prixKit" value={inputs.prixKit} onChange={handleChange} />
      </label>
      <button onClick={calculer}>Calculer</button>

      {results && (
        <div style={{ marginTop: '20px', background: '#f9f9f9', padding: '15px', border: '1px solid #ddd' }}>
          <p>🔋 Production estimée : {results.production} kWh/an</p>
          <p>💰 Gain annuel : {results.gainAnnuel} €</p>
          <p>⏳ Retour sur investissement : {results.retourInvest} ans</p>
          <p>💸 Facture sans photovoltaïque : {results.factureSansPV} €</p>
          <p>💡 Nouvelle facture annuelle avec photovoltaïque : {results.factureAvecPV} €</p>
        </div>
      )}
    </div>
  );
}

export default App;
